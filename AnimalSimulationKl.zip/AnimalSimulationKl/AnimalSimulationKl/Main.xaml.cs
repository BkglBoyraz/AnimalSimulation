﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace AnimalSimulationKl
{
    /// <summary>
    /// Interaktionslogik für Main.xaml
    /// </summary>
    public partial class Main : Window
    {
        Shop shop = new Shop();

        Animal1 z = new Animal1();
        Animal2 d = new Animal2();
        Animal3 t = new Animal3();

        
        //Polymorphi Liste mit verschiedenen Objekten die von der selben klasse erben! 
               
        DispatcherTimer timer = new DispatcherTimer();

        public Main()
        {
            InitializeComponent();
            
            Label_Tier1.Content = z.Animalname;
            Label_Tier2.Content = d.Animalname;
            Label_Tier3.Content = t.Animalname;

            initValues();
            timer.Interval = TimeSpan.FromMilliseconds(100);
            timer.Tick += t_Tick;
            timer.Start();
            //Polymorphi Liste mit verschiedenen Objekten die von der selben klasse erben! 
        }

        private void t_Tick(object sender, EventArgs e)
        {
            initValues();
            Animal[] animals = { z, d, t };

            for (int i = 0; i < animals.Length; i++)
            {
                animals[i].health();
            }

        }
        private void initValues()
        {
            gesundheit1.Value = GameManager.healthAnimal1;
            futter1.Value = GameManager.foodAnimal1;

            gesundheit2.Value = GameManager.healthAnimal2;
            futter2.Value= GameManager.foodAnimal2;

            gesundheit3.Value = GameManager.healthAnimal3;
            futter3.Value= GameManager.foodAnimal3;

            Label_Current_Food.Content = GameManager.food;
            Label_Current_Money.Content = GameManager.money;
            Label_Current_Toys.Content = GameManager.Animal_Toy;
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            shop.Show();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            z.eat();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            z.stroke();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            d.eat();
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            z.stroke();
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            t.eat();
        }

        private void Button_Click_6(object sender, RoutedEventArgs e)
        {
            t.stroke();
        }

        private void Button_Click_7(object sender, RoutedEventArgs e)
        {
            z.Hit();
            //sound.Play();
        }

        private void Button_Click_8(object sender, RoutedEventArgs e)
        {
            d.Hit();
            //sound.Play();
        }

        private void Button_Click_9(object sender, RoutedEventArgs e)
        {
            t.Hit();
            //sound.Play();
        }

        private void Button_Click_10(object sender, RoutedEventArgs e)
        {
            Animal[] animals = {z,d,t };

            for (int i = 0; i < animals.Length; i++)
            {
                animals[i].Hit();
            }
        }
    }
}
