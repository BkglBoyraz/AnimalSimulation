﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace AnimalSimulationKl
{
    internal class Animal2 : Animal
    {
        public string Animalname = "Dinosaurier";

        public override void health()
        {

            if (GameManager.healthAnimal2 <= 0)
            {
                Application.Current.Shutdown();
            }

        }
        public override void Hit()
        {
            GameManager.healthAnimal2 -= 10;
        }

        public override void stroke()
        {
            GameManager.healthAnimal2 += 1.5;
        }

        public override void eat()
        {
            if (GameManager.food > 0)
            {
                GameManager.foodAnimal2 += 1.5;
                GameManager.healthAnimal2 += 1.5;
                GameManager.food -= 1;
            }
        }
    }
}
