﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace AnimalSimulationKl
{
    internal class Animal
    {
        public string animalName = "";

        

        public virtual void health()
        {
           
        }

        public virtual void eat()
        {

        }

        public virtual void stroke()
        {
            
        }
        public virtual void Hit()
        {
            
        }
    }
}
