﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalSimulationKl
{
    internal class GameManager
    {
       
        public static int money = 3500;
        public static int food = 0;
        public static int Animal_Toy = 0;

        public static int hunger;

        public static double healthAnimal1 = 50;
        public static double foodAnimal1 = 15;

        public static double healthAnimal2 = 50;
        public static double foodAnimal2 = 0;

        public static double healthAnimal3 = 50;
        public static double foodAnimal3 = 10;

    }
}
