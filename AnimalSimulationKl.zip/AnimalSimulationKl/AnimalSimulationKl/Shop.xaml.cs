﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace AnimalSimulationKl
{
    /// <summary>
    /// Interaktionslogik für Shop.xaml
    /// </summary>
    public partial class Shop : Window
    {
        DispatcherTimer timer = new DispatcherTimer();
        public Shop()
        {
            InitializeComponent();
            Label_Current_Money2.Content = GameManager.money.ToString();
            Label_Current_Toys2.Content = GameManager.Animal_Toy.ToString();
            Label_Current_Food2.Content = GameManager.food.ToString();
            timer.Interval = TimeSpan.FromMilliseconds(100);
            timer.Tick += t_Tick;
            timer.Start();
        }
        private void t_Tick(object sender, EventArgs e)
        {
            
            MoneyAccount();
            IngameValues();
        }
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            GameManager.money -= 10;
            GameManager.food += 1;
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            GameManager.money -= 20;
            GameManager.food += 1;
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            GameManager.money -= 50;
            GameManager.food += 1;
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            GameManager.money -= 100;
            GameManager.food += 1;
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            GameManager.money -= 20;
            GameManager.Animal_Toy += 1;
        }

        private void Button_Click_6(object sender, RoutedEventArgs e)
        {
            GameManager.money -= 40;
            GameManager.Animal_Toy += 1;
        }

        private void Button_Click_7(object sender, RoutedEventArgs e)
        {
            GameManager.money -= 60;
            GameManager.Animal_Toy += 1;
        }

        private void Button_Click_8(object sender, RoutedEventArgs e)
        {
            GameManager.money -= 80;
            GameManager.Animal_Toy += 1;
        }

        private void Button_Click_9(object sender, RoutedEventArgs e)
        {
            GameManager.money -= 100;
            GameManager.Animal_Toy += 1;
        }

        public void IngameValues()
        {
            Label_Current_Food2.Content = GameManager.food;
            Label_Current_Money2.Content = GameManager.money;
            Label_Current_Toys2.Content = GameManager.Animal_Toy;
        }

        public void MoneyAccount()
        {
            if (GameManager.money < 10)
            {
                Buy_Food.IsEnabled = false;
            }
            else if (GameManager.money < 20)
            {
                Buy_Food1.IsEnabled = false;
                Buy_Spielzeug.IsEnabled = false;
            }
            else if (GameManager.money < 50)
            {
                Buy_Food2.IsEnabled = false;
            }
            else if (GameManager.money < 100)
            {
                Buy_Food3.IsEnabled = false;
            }
            else if (GameManager.money < 40)
            {
                Buy_Spielzeug1.IsEnabled = false;
            }
            else if (GameManager.money < 60)
            {
                Buy_Spielzeug2.IsEnabled = false;
            }
            else if (GameManager.money < 80)
            {
                Buy_Spielzeug3.IsEnabled = false;
            }
            else if (GameManager.money < 100)
            {
                Buy_Spielzeug4.IsEnabled = false;
            }


        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Main main = new Main();
            this.Close();
            main.Show();
        }
    }
}
