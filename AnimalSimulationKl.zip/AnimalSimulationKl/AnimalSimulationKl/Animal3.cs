﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace AnimalSimulationKl
{
    internal class Animal3 : Animal
    {
        public string Animalname = "Tiger";

        public override void health()
        {
            if (GameManager.healthAnimal3 <= 0)
            {
                Application.Current.Shutdown();
            }
        }
        public override void Hit()
        {
            GameManager.healthAnimal3 -= 10;
        }

        public override void stroke()
        {
            GameManager.healthAnimal3 += 1.5;
        }

        public override void eat()
        {
            if (GameManager.food > 0)
            {
                GameManager.foodAnimal3 += 1.5;
                GameManager.healthAnimal3 += 1.5;
                GameManager.food -= 1;
            }
        }
    }
}
